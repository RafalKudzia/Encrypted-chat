/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wraki.czat;

import java.math.BigInteger;
import java.util.Vector;

/**
 *
 * @author Rafi
 */
public class GenPierwiastekPierwotnyG {


    private    BigInteger pr, p, phi;
    public GenPierwiastekPierwotnyG(BigInteger p){
        this.p = p;
        this.phi = (this.p).subtract(BigInteger.ONE);
        Vector<BigInteger> primitiveRoots =  this.getPrimitiveRoot(this.p, this.phi);
        //this.pr = primitiveRoots.get(new Random().nextInt(primitiveRoots.size()));
        this.pr = primitiveRoots.get(0);
    }

    public BigInteger getPr() {
        return pr;
    }

    private Vector<BigInteger> getPrimitiveRoot(BigInteger p, BigInteger phi){
        Vector<BigInteger> primeFactors = this.genPrimesFactorsList(phi);
        Vector<BigInteger> primitiveRoots = new Vector<>();
        for(BigInteger i = new BigInteger("2");i.compareTo(p)<0;i=i.add(BigInteger.ONE)){
            if (primitiveRoots.size()!= 0)
                break;
            boolean flg = false;
            for(BigInteger l: primeFactors){
                BigInteger iBig = (i);
                BigInteger phiBig = (phi.divide(l));
                BigInteger pBig = (p);
                BigInteger pRootBig = iBig.modPow(phiBig, pBig);
                if(pRootBig.compareTo(BigInteger.valueOf(1))==0){
                    flg = true;
                    break;
                }
            }
            if(!flg)
                primitiveRoots.add(i);

        }
        return primitiveRoots;
    }

    private Vector<BigInteger> genPrimesFactorsList(BigInteger phi){
        Vector<BigInteger> primesFactors = new Vector<>();
        while(phi.mod(new BigInteger("2")).equals(BigInteger.ZERO) ){

            primesFactors.add((BigInteger.valueOf(2)));
            phi= phi.divide(BigInteger.valueOf(2));

        }
        for(BigInteger i = BigInteger.valueOf(3);i.doubleValue()<=(Math.sqrt(phi.doubleValue()));i=i.add(BigInteger.valueOf(2))){
            if (primesFactors.size()!=0)
                break;
            if(phi.mod(i).equals(BigInteger.ZERO)){
                primesFactors.add(i);
                phi=phi.divide(i);

            }
        }
        if(phi.compareTo(BigInteger.valueOf(2))>0){
            primesFactors.add(phi);

        }
        return primesFactors;
    }
}
