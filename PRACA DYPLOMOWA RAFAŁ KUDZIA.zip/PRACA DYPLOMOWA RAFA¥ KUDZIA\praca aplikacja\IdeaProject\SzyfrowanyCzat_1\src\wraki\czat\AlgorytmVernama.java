/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wraki.czat;

/**
 *
 * @author Rafi
 */
public class AlgorytmVernama {


    public String zakoduj(String wiad) {


        int wiadLength = wiad.length();
        byte[] asciiPomoc = wiad.getBytes();
        int[] ascii = new int[wiadLength];
        int[] kluczJednorazowy = new int[wiadLength];
        int[] zakodowany = new int[wiadLength];

        for (int i =0;i<asciiPomoc.length;i++)
            if(asciiPomoc[i]<0)
                ascii[i] = asciiPomoc[i]+256;
            else
                ascii[i] = asciiPomoc[i];

        StringBuffer zakod = new StringBuffer();

        for(int i = 0; i< wiadLength;i++)
        {
            kluczJednorazowy[i] = (int) (Math.random()*255);
            zakodowany[i] = ascii[i]^kluczJednorazowy[i];
            zakod.append(String.format("%02x",(zakodowany[i])));
        }

        for(int i = 0; i< wiadLength;i++)
        {
            zakod.append(String.format("%02x",(kluczJednorazowy[i])));
        }

        return zakod.toString();

    }

    public String odkoduj(String wiad)
    {

        int wiadLenght = wiad.length(); // dlugosc wiadomosci
        String wiadomosc;
        String klucz;
        StringBuffer odkod = new StringBuffer();


        // ---- rozbicie wiadomosci na zaszyfrowana i klucz ---
        wiadomosc = wiad.substring(0, wiadLenght/2);
        klucz = wiad.substring(wiadLenght/2,wiadLenght);
        klucz = klucz.trim();
        //---------------------------------------------------
        int[] kluczDekodujacy = new int[klucz.length()/2];
        int[] wiaDoDekodowania = new  int[wiadomosc.length()/2];
        int[] wiadomoscOdkodowana = new int[wiadomosc.length()/2];
        byte[] wiadomoscOdkodowanaPomoc = new byte[wiadomoscOdkodowana.length];
        wiaDoDekodowania = podzielString(wiadomosc);//wywolanie metody w wyniku ktorej otrzymujemy wiadomosc i klucz w formie tablicy ascii
        kluczDekodujacy = podzielString(klucz);
        String pom ="";

        for(int i = 0;i<wiadomoscOdkodowana.length;i++)
        {
            wiadomoscOdkodowana[i] = wiaDoDekodowania[i]^kluczDekodujacy[i];
            if (wiadomoscOdkodowana[i]>127)
                wiadomoscOdkodowanaPomoc[i]=(byte) (wiadomoscOdkodowana[i]-256);
            else
                wiadomoscOdkodowanaPomoc[i]=(byte) wiadomoscOdkodowana[i];
            //odkod.append( wiadomoscOdkodowana[i]);

        }
        pom=new String(wiadomoscOdkodowanaPomoc);
        //return odkod.toString();
        return pom;

    }

    private int [] podzielString(String podziel)// metoda rozbijajaca stringa na tablice ascii
    {

        int [] pom = new int[podziel.length()/2];
        String pom1;

        for(int i = 0;i< podziel.length();i+=2)
        {
            pom1 = podziel.substring(i,i+2);
            pom[i/2] = Integer.parseInt(pom1,16);
        }

        return  pom;
    }

}
