/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wraki.czat;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Vector;

/**
 *
 * @author Rafi
 */
public class AlgorytmDiffieHelman {

    SecureRandom rnd = new SecureRandom();
    private BigInteger p, g, privateX, privateY, publicKeyX, publicKeyY, privateKey;

    public AlgorytmDiffieHelman() {

    }


    public void setPrivateKey(BigInteger k)
    {
        this.privateKey = k;
    }

    public BigInteger getPrivateKey()
    {
        return this.privateKey;
    }
    public void GenerujPublicKeyX() {
        this.publicKeyX = g.modPow(privateX, p);
    }

    public void GenerujPublicKeyY() {
        this.publicKeyY = g.modPow(privateY, p);
    }

    public void GenerujPierwszaIpierwiastek() {

        this.p = new GeneratorLiczbyPierwszej().getPrime();
        this.g = new GenPierwiastekPierwotnyG(this.p).getPr();

    }

    public void GenerujPrivateY(int ilBit) {
        BigInteger pom;

        do {
            pom = BigInteger.probablePrime(ilBit, rnd);
        } while (pom.compareTo(p.subtract(new BigInteger("2"))) >= 0);

        this.privateY = pom;
    }

    public void GenerujPrivateX(int ilBit) {
        BigInteger pom;

        do {
            pom = BigInteger.probablePrime(ilBit, rnd);
        } while (pom.compareTo(p.subtract(new BigInteger("2"))) >= 0);

        this.privateX = pom;

    }

    public BigInteger getP() {
        return this.p;
    }

    public BigInteger getG() {
        return this.g;
    }

    public void setP(BigInteger p) {
        this.p = p;
    }

    public void setG(BigInteger g) {
        this.g = g;
    }

    public BigInteger getPrivateX() {
        return this.privateX;
    }

    public BigInteger getPrivateY() {
        return this.privateY;
    }

    public BigInteger getPublicKeyX() {
        return publicKeyX;
    }

    public BigInteger getPublicKeyY() {
        return publicKeyY;
    }

    public void setPublicKeyX(BigInteger n)
    {
        this.publicKeyX = n;
    }

    public void setPublicKeyY(BigInteger n)
    {
        this.publicKeyY = n;
    }
}
