/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wraki.czat;

/**
 *
 * @author Rafi
 */
public class AlgorytmCezara{


    public  String zakoduj(String odkodowany,int wartoscKlucza){

        int dlugosc = odkodowany.length();
        int[] ascii = new int[dlugosc];

        StringBuffer zakodowany =new StringBuffer();
        char c;



        for(int i=0;i<dlugosc;i++)		// W tych linia nast�puje ...
        {
            ascii[i]= ((int) odkodowany.charAt(i));

        }
        for(int i=0;i<dlugosc;i++)
        {
            c=(char)ascii[i];
            if((c!='\n')&&(c!=' '))
                zakodowany.append(c+=wartoscKlucza);
            else
                zakodowany.append(c);
        }

        return zakodowany.toString();
    }

    public String odkoduj(String zakodowany,int wartoscKlucza){

        StringBuffer odkodowany = new StringBuffer();
        int dlugosc = zakodowany.length();
        int[] ascii = new int[dlugosc];
        char c;

        for(int i=0;i<dlugosc;i++)
        {
            ascii[i]= ((int) zakodowany.charAt(i));

        }
        for(int i=0;i<dlugosc;i++)
        {
            c=(char)ascii[i];
            if((c!='\n')&&(c!=' '))
                odkodowany.append(c-=wartoscKlucza);
            else
                odkodowany.append(c);
        }


        return odkodowany.toString();
    }
}


