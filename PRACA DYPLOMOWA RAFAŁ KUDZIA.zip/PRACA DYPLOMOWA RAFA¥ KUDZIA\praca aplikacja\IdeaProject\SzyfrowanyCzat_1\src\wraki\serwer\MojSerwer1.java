package wraki.serwer;

// zimportowanie potrzebnych pakiet�w

import java.util.*;
import java.io.*;
import java.net.*;

public class MojSerwer1
{
    ArrayList klientArrayList; // lista klient�w serwera
    PrintWriter printWritter;
    //uruchomienie programu
    public static void main(String[] arg)
    {
        MojSerwer1 s = new MojSerwer1();
        s.startSerwer();

    }

    // metoda uruchamiaj�ca serwer
    public void startSerwer()
    {
        klientArrayList = new ArrayList();//lista klient�w

        try
        {
            ServerSocket serverSocket = new ServerSocket(5000); // otwarcie nas�uchiwania na porcie 5000

            //g��wna p�tla programu odpowiedzialna za nas�uch serwera
            while(true)
            {
                Socket socket = serverSocket.accept(); //akceptacja polaczen przychodz�cych an porcie 5000
                System.out.println("Slucham : " + serverSocket);//komunikat na jakim ip i porcie serwer nas�uchuje
                printWritter = new PrintWriter(socket.getOutputStream());//zmienna przechwuj�ca komunikaty przychodz�ce, kt�re maj� by� rozsy�ane do innych klient�w
                klientArrayList.add(printWritter);//dodanie klienta do listy

                Thread t = new Thread(new SerwerKlient(socket));//tworzenie w�tku dla ka�dego nowego klienta
                t.start();// uruchomienie w�tku
            }
        }

        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    //klasa wewnetrzna -  watek klienta
    class SerwerKlient implements Runnable
    {
        Socket socket;
        BufferedReader bufferedReader;//odczytywanie komunikatow od klientow

        //konstruktor//

        public SerwerKlient(Socket socketClient)
        {
            try
            {
                System.out.println("Polaczony. ");
                socket = socketClient;
                bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));//odczyt strumienia wejsciowego
            }

            catch(Exception ex)
            {
                ex.printStackTrace();
            }
        }



        @Override
        public void run()
        {
            String str; // pobranie danych w bufferedReader
            PrintWriter pw = null;// zmienna slu��ca do rozsy�ania komunikat�w

            try
            {
                while((str = bufferedReader.readLine()) != null)
                {
                    System.out.println("Odebrano >> " + str);

                    Iterator it = klientArrayList.iterator();//it s�u�y do przej�cia przez list� klient�w
                    while(it.hasNext())
                    {
                        pw = (PrintWriter) it.next();//poni�sze trzy linie odpowiedzialne
                        pw.println(str);			//s� za rozes�anie przychodz�cych komunikat�w
                        pw.flush();					//do wszystkich pod��czonych klient�w
                    }

                }
            }
            catch(Exception e)
            {
            }
        }

    }
}
