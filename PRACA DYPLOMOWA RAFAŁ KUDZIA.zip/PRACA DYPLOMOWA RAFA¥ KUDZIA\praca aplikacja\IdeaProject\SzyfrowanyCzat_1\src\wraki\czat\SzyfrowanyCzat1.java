/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wraki.czat;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.Socket;

import static java.lang.Thread.sleep;

public class SzyfrowanyCzat1 {


    private ButtonGroup rodzajSzyfru;
    private JRadioButton bezSzyfrowania;
    private JRadioButton szyfrCezara;
    private JRadioButton szyfrVernama;
    private JRadioButton uzgadnianieKlucza;
    private JButton uzgodnijKlucz;
    private JButton przyciskWyslij;
    private JTextArea odebraneWiadomosci;
    private JTextField wiadomosc;
    private JTextField przesuniecieCezar;
    private BufferedReader czytelnik;
    private PrintWriter pisarz;
    private Socket gniazdo;
    private String imie = "";
    private String adresIP = "";
    private JPanel panelGlowny;
    private JLabel kluczPrywatny;
    private AlgorytmDiffieHelman adf = new AlgorytmDiffieHelman();

    public static void main(String[] args) {

        // ---- uruchomienie aplikacji------
        SzyfrowanyCzat1 szyfrowanyCzat1 = new SzyfrowanyCzat1();
        szyfrowanyCzat1.doDziela();

    }

    public void doDziela(){

        //----definiowanie okna klienta czatu-----------------------
        JFrame ramka = new JFrame("SZYFROWANY CZAT 1.0");
        JPanel panelGlowny = new JPanel();

        panelGlowny.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;

        odebraneWiadomosci = new JTextArea(15,40);
        odebraneWiadomosci.setEditable(false);
        odebraneWiadomosci.setLineWrap(true);

        JScrollPane przewijanie = new JScrollPane(odebraneWiadomosci);
        przewijanie.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        przewijanie.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        c.insets = new Insets(0,0,20,0);
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth =4;
        panelGlowny.add(przewijanie,c);

        bezSzyfrowania = new JRadioButton("Bez szyfrowania",true);
        c.insets = new Insets(0,0,5,0);
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth =1;
        panelGlowny.add(bezSzyfrowania,c);

        szyfrCezara = new JRadioButton("Szyfr Cezara",false);
        c.gridx = 1;
        c.gridy = 1;
        panelGlowny.add(szyfrCezara,c);

        przesuniecieCezar = new JTextField(2);
        c.gridx = 2;
        c.gridy =1;
        panelGlowny.add(przesuniecieCezar,c);

        szyfrVernama = new JRadioButton("Szyfr Vernama",false);
        c.anchor = GridBagConstraints.WEST;
        c.gridx = 3;
        c.gridy = 1;
        panelGlowny.add(szyfrVernama,c);

        uzgadnianieKlucza = new JRadioButton("Uzgadnianie klucza DH",false);
        uzgadnianieKlucza.addActionListener(new UzgadnianieKluczaListener());
        c.gridx = 0;
        c.gridy = 3;
        panelGlowny.add(uzgadnianieKlucza,c);

        rodzajSzyfru = new ButtonGroup();
        rodzajSzyfru.add(bezSzyfrowania);
        rodzajSzyfru.add(szyfrCezara);
        rodzajSzyfru.add(szyfrVernama);
        rodzajSzyfru.add(uzgadnianieKlucza);

        wiadomosc = new JTextField(20);
        c.gridwidth =3;
        c.gridx = 0;
        c.gridy = 2;
        panelGlowny.add(wiadomosc,c);
        wiadomosc.setActionCommand("enter");

        przyciskWyslij = new JButton("Wy�lij");
        przyciskWyslij.addActionListener(new PrzyciskWyslijListener());
        wiadomosc.addActionListener(new PrzyciskWyslijListener());
        c.gridx = 3;
        c.gridy = 2;
        panelGlowny.add(przyciskWyslij,c);

        uzgodnijKlucz = new JButton("Uzgodnij klucz");
        uzgodnijKlucz.setEnabled(false);
        uzgodnijKlucz.addActionListener(new PrzyciskUzgodnijKluczListener());
        c.gridx = 3;
        c.gridy = 3;
        panelGlowny.add(uzgodnijKlucz,c);

        kluczPrywatny = new JLabel();
        kluczPrywatny.setText("Tw�j klucz prywatny : ");
        c.gridx = 0;
        c.gridy = 4;
        panelGlowny.add(kluczPrywatny,c);

        adresIP = JOptionPane.showInputDialog("Podaj adres IP serwera :");
        imie = JOptionPane.showInputDialog("Podaj imi� :");
        konfigurujKomunikacje();

        ramka.getContentPane().add(BorderLayout.CENTER,panelGlowny);
        ramka.setSize(480,450);
        ramka.setResizable(false);
        ramka.setVisible(true);

        //-------uruchomienie w�tku odbircy------------------------
        Thread watekOdbiorcy = new Thread(new OdbiorcaKomunikatow());
        watekOdbiorcy.start();
    }

    private void konfigurujKomunikacje() {
        try {
            //-------Konfiguracja i nawi�zanie po��czenia z serwerem-----------------------------
            gniazdo = new Socket(adresIP, 5000);
            InputStreamReader czytelnikStrm = new InputStreamReader(gniazdo.getInputStream());
            czytelnik = new BufferedReader(czytelnikStrm);
            pisarz = new PrintWriter(gniazdo.getOutputStream());
            odebraneWiadomosci.append("Po��czono do: "+ gniazdo.getInetAddress().getHostAddress()+" port: "+ gniazdo.getPort() + "\n");
            odebraneWiadomosci.append("Witaj " + imie + " w aplikacji SZYFROWANY CZAT.\n");

        }
        catch (IOException e){
            e.printStackTrace();
        }

    }

    public class PrzyciskUzgodnijKluczListener implements ActionListener{

        //-------kalsa odpowiedzialna za uzgadnianie klucza prywatnego przy pomocy algorytmu DH
        @Override
        public void actionPerformed(ActionEvent e) {

            uzgodnijKlucz.setEnabled(false);
            odebraneWiadomosci.append("Uzgadniam klucz przywatny... \n");
            pisarz.println(imie+ ":" +  "Uzgadniam klucz przywatny...");
            pisarz.flush();
            pisarz.write("");

            adf.GenerujPierwszaIpierwiastek();//generuje liczb? pierwsz? i pierwiastek

            try {
                sleep(1000);


                if (adf.getP() != null) { // wysy�anie liczby pierwszej
                    odebraneWiadomosci.append("Wysy�am liczb� pierwsz� : " + adf.getP().toString(16) + "\n");
                    pisarz.println(imie+ ":" + adf.getP());
                    pisarz.flush();
                    pisarz.write("");
                    adf.GenerujPrivateX(32); // generowanie liczby prywatnej
                    adf.GenerujPublicKeyX();//generowanie publicznego klucza X
                }

                sleep(1000);

                if(adf.getG() != null ){// wyslanie generatora
                    odebraneWiadomosci.append("Wysy�am generator : " +adf.getG().toString(16) +"\n");
                    pisarz.println(imie+ ":" + adf.getG());
                    pisarz.flush();
                    pisarz.write("");

                }
                sleep(1000);

                if(adf.getPublicKeyX() != null){// wys?anie klucza publicznego X
                    odebraneWiadomosci.append("Wysy�am klucz publiczny "+imie+" : " +adf.getPublicKeyX().toString()+"\n");
                    pisarz.println(imie+ ":" + adf.getPublicKeyX());
                    pisarz.flush();
                    pisarz.write("");
                }

            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
    }
    public class UzgadnianieKluczaListener implements ActionListener{

        //------Klasa przygotowuj�ca komunikator do uzgadniania klucza prywatnego
        @Override
        public void actionPerformed(ActionEvent e) {
            if(adf.getPrivateKey() == null) {
                przyciskWyslij.setEnabled(false);

                wiadomosc.setEnabled(false);
                uzgodnijKlucz.setEnabled(true);
            } else {
                uzgodnijKlucz.setEnabled(false);
                przyciskWyslij.setEnabled(true);
                wiadomosc.setEnabled(true);
            }


        }
    }

    public class PrzyciskWyslijListener implements ActionListener {

        //-----Klasa obs�uguj�ca szyfrowanie przesy�anych wiadomo�ci
        public void actionPerformed(ActionEvent ev){
            String pomStr;

            if(bezSzyfrowania.isSelected())
            {
                try {
                    odebraneWiadomosci.append(">> ja : " + wiadomosc.getText() + "\n");
                    odebraneWiadomosci.setCaretPosition(odebraneWiadomosci.getText().length());

                     pomStr = wiadomosc.getText();
                    pisarz.println(imie+ ":" + pomStr);
                    pisarz.flush();
                }
                catch (Exception e){
                    e.printStackTrace();
                }
                wiadomosc.setText("");
                wiadomosc.requestFocus();
            }

             if(szyfrCezara.isSelected())
            {

                AlgorytmCezara algorytmCezara = new AlgorytmCezara();
                if (przesuniecieCezar.getText().equals(""))
                    JOptionPane.showMessageDialog(null,"Podaj przesuni�cie szyfru!!!");
                else {

                    if(wiadomosc.getText().toLowerCase().contains("�")||wiadomosc.getText().toLowerCase().contains("�")||wiadomosc.getText().toLowerCase().contains("�")||wiadomosc.getText().toLowerCase().contains("�")||wiadomosc.getText().toLowerCase().contains("�")||wiadomosc.getText().toLowerCase().contains("�")||wiadomosc.getText().toLowerCase().contains("�")||wiadomosc.getText().toLowerCase().contains("�")||wiadomosc.getText().toLowerCase().contains("�"))
                        odebraneWiadomosci.append("Algorytm Cezara nie obs�uguje polskich znak�w!"+"\n");
                    else{
                    odebraneWiadomosci.append(">> ja : " + wiadomosc.getText() + "\n");
                    pomStr = algorytmCezara.zakoduj(wiadomosc.getText(), Integer.parseInt(przesuniecieCezar.getText()));
                    pisarz.println(imie + ":" + pomStr);
                    pisarz.flush();
                    wiadomosc.setText("");
                    wiadomosc.requestFocus();
                }
                }
            }
             if(szyfrVernama.isSelected())
            {
                AlgorytmVernama algorytmVernama = new AlgorytmVernama();
                odebraneWiadomosci.append(">> ja : " + wiadomosc.getText() + "\n");
                pomStr = algorytmVernama.zakoduj(wiadomosc.getText());
                pisarz.println(imie+ ":" + pomStr);
                pisarz.flush();
                wiadomosc.setText("");
                wiadomosc.requestFocus();

            }

       }



    }

    public class OdbiorcaKomunikatow implements Runnable{// w�tek odbiorcy


        @Override
        public void run() {
            String wiadom;
            String pomStr;

            try {
                while ((wiadom = czytelnik.readLine()) != null)
                {

                    String subString[] = wiadom.split(":");
                    if (!subString[0].equals(imie))
                    {
                        if (bezSzyfrowania.isSelected())
                        {
                            odebraneWiadomosci.append(">> " + wiadom + "\n");
                        }

                        if (szyfrCezara.isSelected())
                        {
                            if (przesuniecieCezar.getText().equals(""))
                                JOptionPane.showMessageDialog(null,"Sprawd� poprawno�� przesuni�cia szyfru!!!");
                            else {
                                AlgorytmCezara algorytmCezara = new AlgorytmCezara();
                                pomStr = algorytmCezara.odkoduj(subString[1], Integer.parseInt(przesuniecieCezar.getText()));
                                odebraneWiadomosci.append((">> " + subString[0] + " : " + pomStr + "\n"));
                            }
                        }

                        if(szyfrVernama.isSelected())
                        {
                            AlgorytmVernama algorytmVernama = new AlgorytmVernama();
                            pomStr = algorytmVernama.odkoduj(subString[1]);
                            odebraneWiadomosci.append((">> "+ subString[0]+" : "+pomStr + "\n"));
                        }

                        if (subString[1].equals("Uzgadniam klucz przywatny...")) {
                            uzgodnijKlucz.setEnabled(false);
                            uzgadnianieKlucza.setSelected(true);
                            przyciskWyslij.setEnabled(false);
                        }
                        if (uzgadnianieKlucza.isSelected())
                        {
                            if (subString[1].equals("Uzgadniam klucz przywatny..."))
                            {
                                odebraneWiadomosci.append("Uzgadniam klucz przywatny... \n");
                                continue;
                            }

                            if (adf.getP() == null) {
                                adf.setP(new BigInteger(subString[1]));
                                odebraneWiadomosci.append("Odebra�em liczb� pierwsz� : " + adf.getP().toString(16)+ "\n");
                                continue;
                            }

                            if (adf.getG() == null) {
                                adf.setG(new BigInteger(subString[1]));
                                odebraneWiadomosci.append("Odebra�em generator : " + adf.getG().toString(16) + "\n");
                                adf.GenerujPrivateY(32);
                                adf.GenerujPublicKeyY();
                                continue;
                            }

                            if(adf.getPublicKeyX()==null)
                            {
                                adf.setPublicKeyX(new BigInteger(subString[1]));
                                odebraneWiadomosci.append("Odebra�em klucz publiczny "+subString[0] +" : " +subString[1]+ "\n");
                                adf.setPrivateKey(adf.getPublicKeyX().modPow(adf.getPrivateY(), adf.getP()));
                                odebraneWiadomosci.append("Uwstawiam klucz prywatny : " + adf.getPrivateKey().toString(16)+"\n");
                                kluczPrywatny.setText("Tw�j klucz prywatny : "+ adf.getPrivateKey().toString(16));
                                if (adf.getPublicKeyY() != null) {
                                    odebraneWiadomosci.append("M�j klucz publiczny to : "+adf.getPublicKeyY().toString()+ " wysy�am ...\n");
                                    pisarz.println(imie+ ":" +adf.getPublicKeyY());
                                    pisarz.flush();
                                    pisarz.write("");
                                }
                                przyciskWyslij.setEnabled(true);
                                wiadomosc.setEnabled(true);
                                continue;
                            }

                            if(adf.getPublicKeyY()==null)
                            {
                                adf.setPublicKeyY(new BigInteger(subString[1]));
                                odebraneWiadomosci.append("Odebra�em klucz publiczny " +subString[0] +" : " +subString[1]+ "\n");
                                adf.setPrivateKey(adf.getPublicKeyY().modPow(adf.getPrivateX(), adf.getP()));
                                odebraneWiadomosci.append("Uwstawiam klucz prywatny : " +adf.getPrivateKey().toString(16)+"\n");
                                kluczPrywatny.setText("Tw�j klucz prywatny : "+adf.getPrivateKey().toString(16));
                                przyciskWyslij.setEnabled(true);
                                wiadomosc.setEnabled(true);
                                continue;
                            }
                        }
                    }
                    odebraneWiadomosci.setCaretPosition(odebraneWiadomosci.getText().length());
                }
            } catch (Exception e) {
                odebraneWiadomosci.append("UPSS CO� POSZ�O NIE TAK!!! Uruchom ponownie aplikacj�");
            }
        }
    }
}


