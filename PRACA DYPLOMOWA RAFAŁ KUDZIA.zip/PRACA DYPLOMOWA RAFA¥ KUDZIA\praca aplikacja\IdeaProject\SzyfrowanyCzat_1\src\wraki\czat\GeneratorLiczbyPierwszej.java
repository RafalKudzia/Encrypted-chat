/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wraki.czat;

import java.math.BigInteger;
import java.security.SecureRandom;

/**
 *
 * @author Rafi
 */
public class GeneratorLiczbyPierwszej {

    private SecureRandom rnd = new SecureRandom();
    private BigInteger prime = this.primeGen(32);//= BigInteger.probablePrime(5, rnd);

    private BigInteger primeGen(int ilBit){
        return BigInteger.probablePrime(ilBit,rnd);
    }

    public BigInteger getPrime(){
        return prime;
    }


}
